{{!-- Your custom partial here --}}

<div class="custom-partial">
  Your custom partial here
</div>