</body>

</html>
<?php /* B:\dev\wamp\www\poultry_slaughterhouse\resources\views/includes/metaFooter.blade.php */ ?>