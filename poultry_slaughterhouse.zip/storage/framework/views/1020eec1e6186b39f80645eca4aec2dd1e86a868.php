<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta content="IE=edge" http-equiv="X-UA-Compatible">
  <meta content="width=device-width,initial-scale=1" name="viewport">
  <meta content="" name="description">
  <meta name="google" content="notranslate" />
  <meta name="csrf-token" content="<?php echo e(@csrf_token()); ?>">
  <meta content="Mashup templates have been developped by Orson.io team" name="author">

  <!-- Disable tap highlight on IE -->
  <meta name="msapplication-tap-highlight" content="no">
  
  
  <link rel="apple-touch-icon" sizes="180x180" href="./assets/apple-icon-180x180.png">
  <link href="./assets/favicon.ico" rel="icon">

  <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
  
  <link href="<?php echo e(asset('css/all.min.css')); ?>" rel="stylesheet">


  

</head>

<body>
<?php /* B:\dev\wamp\www\poultry_slaughterhouse\resources\views/includes/metaHeader.blade.php */ ?>